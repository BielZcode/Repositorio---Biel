<div class="row">
                <div class="column">
                    <h3 class="tittle">1. Endereço de Cobrança</h3>
                    <div class="input-box">
                        <span>nome completo:</span>
                        <input type="text" placeholder="Seu Nome Completo" required>
                    </div>
                    <div class="input-box">
                        <span>Email:</span>
                        <input type="email" placeholder="Seu Email" required>
                    </div>
                    <div class="input-box">
                        <span>Endereço:</span>
                        <input type="text" placeholder="Seu Endereço" required>
                    </div>
                    <div class="input-box">
                        <span>Cidade:</span>
                        <input type="text" placeholder="Sua Cidade" required>
                    </div>
                    <div class="input-box">
                        <span>Estado:</span>
                        <input type="text" placeholder="Seu Estado" required>
                    </div>
                    <div class="input-box">
                        <span>Cep:</span>
                        <input type="number" placeholder="123 456" required>
                    </div>
                    <div class="input-box">
                        <span>Cep:</span>
                        <input type="text" placeholder="Seu Cep" required>
                    </div>
                </div>

                <div class="column">
                    <h3 class="tittle">2. Pagamento</h3>
                    <div class="input-box">
                        <span>Cartões aceitos:</span>
                        <input type="text" placeholder="Sarah Alves" required>
                    </div>
                    <div class="input-box">
                        <span>Nome no Cartão:</span>
                        <input type="email" placeholder="Sarah santo alves" required>
                    </div>
                    <div class="input-box">
                        <span>Numero do Catão de Credito:</span>
                        <input type="text" placeholder="1111 2222 3333 4444" required>
                    </div>
                    <div class="input-box">
                        <span>Mês de Experiência:</span>
                        <input type="text" placeholder="Agosto" required>
                    </div>
                    <div class="input-box">
                        <span>Ano de Experiência:</span>
                        <input type="text" placeholder="2025" required>
                    </div>
                    <div class="input-box">
                        <span>CVV:</span>
                        <input type="number" placeholder="123" required>
                    </div>
                </div>
            </div>